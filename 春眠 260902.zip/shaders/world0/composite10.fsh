#version 330 compatibility
#define STAGE_FRAGMENT
#define BLOOM_LEVEL 2
#include "/program/composite_bloom_upsample.glsl"

/* DRAWBUFFERS:1 */
