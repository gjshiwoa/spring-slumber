#version 330 compatibility
#define STAGE_VERTEX
#include "/program/gbuffers_translucent_simple.glsl"
