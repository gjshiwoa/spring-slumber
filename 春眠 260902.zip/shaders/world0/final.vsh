#version 330 compatibility
#define STAGE_VERTEX
#include "/program/final.glsl"
