#version 330 compatibility
#define STAGE_FRAGMENT
#define BLOOM_LEVEL 4
#include "/program/composite_bloom.glsl"
